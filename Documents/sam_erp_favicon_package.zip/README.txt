SAM ERP Favicon package

Use favicon.ico and/or favicon-32.png in your frontend public folder.
Example HTML: <link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">

PNG icons have transparent backgrounds except apple-touch-icon.png, which has a white background.
